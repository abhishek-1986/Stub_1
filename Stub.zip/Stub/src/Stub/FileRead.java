package Stub;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import org.json.JSONObject;

public class FileRead {

	private String[] a ;
	
	public String File_Reader(String filename) throws IOException{
	
		
		int i =0;
		JSONObject jb = new JSONObject();
	FileReader fr = new FileReader("D:\\log\\"+filename+".txt");	
	BufferedReader br = new BufferedReader(fr);	
	String json = null;
	while((json = br.readLine()) != null){
		//sb.append(json);
		
		a[i] = json;
		i++;
	}
	jb.put("name", a[0]);
	jb.put("Age", a[1]);
	
	JSONObject jb2 = new JSONObject();
	jb2.put("Designation",a[2]);
	jb2.put("Salary", a[3]);
	jb2.put("Place", a[4]);
	
	jb.put("WorkDetails", jb2);
	
	jb.put("MartialStatus", a[5]);
	
	return jb.toString();
	}
	
public static void main(String [] args) throws IOException{
	FileRead f = new FileRead();
	String j = f.File_Reader("Abhishek");
	System.out.println(j);
}
	
	
}
