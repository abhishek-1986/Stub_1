package Stub;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;



public class EchoServer {

		public static void main( String[] args) throws IOException, InterruptedException {
			
			Logger log = Logger.getLogger(EchoServer.class.getName());
			PropertyConfigurator.configure("log4j.properties");
			
			System.out.println("Listening for connection on port 10001 ....");
			@SuppressWarnings("resource")
			
			ServerSocket socket = new ServerSocket(10005);
			
		    while(true){
				
				try(Socket clientsocket = socket.accept()){
								
					InputStreamReader isr = new InputStreamReader(clientsocket.getInputStream()); 
					BufferedReader reader = new BufferedReader(isr);
					String currentLine;
				String str= ".";
					while(!str.equals("")){
						currentLine=reader.readLine();
						System.out.println(currentLine);
					
					}
					
					String line = reader.readLine().toString();
					System.out.println(line);
					String b = jsonBuilder.JsonBuilder(line);
					String httpResponse = "HTTP/1.1 200 OK\r\n\r\n" +"\n" + b;
					Thread.sleep(3000);
					clientsocket.getOutputStream().write(httpResponse.getBytes("UTF-8"));
					log.info("Response sent to client");
				}
			
			
			
			}
					}
		
	
		
		
}

