package Stub;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;


import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;



 class Echoerver2 extends Thread {

	public void Run() throws IOException{
		System.out.println("Calling Request Method");
		serviceRequest();
	}
	
	public void serviceRequest() throws IOException{
		System.out.println("Stared threads");
		/*
		Logger log = Logger.getLogger(Echoserver3.class.getName());
		PropertyConfigurator.configure("log4j.properties");
		
		System.out.println("Listening for connection on port 10001 ....");
		@SuppressWarnings("resource")
		
		log.info("the Connection to socket is made ");
		
		log.debug("Sample debug message");
	    log.info("Sample info message");
	    log.warn("Sample warn message");
	    log.error("Sample error message");
	    log.fatal("Sample fatal message");
	    while(true){
			
			try(Socket clientsocket = socket.accept()){
				log.info("Socket Connection accepted from client");
				
				
				InputStreamReader isr = new InputStreamReader(clientsocket.getInputStream()); 
				BufferedReader reader = new BufferedReader(isr);
				String line = reader.readLine();
				String b = "SAnjith";//jsonBuilder.JsonBuilder(line.substring(5));
				String httpResponse = "HTTP/1.1 200 OK\r\n\r\n" +"\n" + b;
				clientsocket.getOutputStream().write(httpResponse.getBytes("UTF-8"));
				log.info("Response sent to client");
			}
		
		
		
 }*/

	}
	
}	
	
class Echoserver3 {

public static void main( String[] args)  {
			
	for(int i =1;i<=5;i++)
	{
				Echoerver2 es = new Echoerver2();
				es.start();
	}						
		   
					}
		
	
		
		


}		