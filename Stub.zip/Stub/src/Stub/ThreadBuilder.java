package Stub;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

class ThreadCreator extends Thread{
	
	Socket clientsocket =null;
	static ServerSocket socket = null;
	static int numOfthreads=10;
	static String log4jfile =null;
	public void run(){
		
		Logger log = Logger.getLogger(ThreadCreator.class.getName());
		PropertyConfigurator.configure("log4j.properties");
		
		while(true){
		log.info(ThreadCreator.currentThread()+" Waiting for  Connection ");	
		try(Socket clientsocket = socket.accept()){
			log.info(ThreadCreator.currentThread()+"Connection Successfull!!! ");
			
			log.info(ThreadCreator.currentThread()+"Reading input Stream ");
			InputStreamReader isr = new InputStreamReader(clientsocket.getInputStream()); 
			BufferedReader reader = new BufferedReader(isr);
			String line = reader.readLine();
			
			
			
			log.info(ThreadCreator.currentThread()+"Calling JSON Builder Class");
			String b = jsonBuilder.JsonBuilder(line.substring(5));
			
			log.info(ThreadCreator.currentThread()+"Forming Response String");
			String httpResponse = ThreadCreator.currentThread()+  "HTTP/1.1 200 OK\r\n\r\n" +"\n" + b;
			
			log.info(ThreadCreator.currentThread()+"Sending Response to client ");
			clientsocket.getOutputStream().write(httpResponse.getBytes("UTF-8"));
			
			log.debug(ThreadCreator.currentThread()+ httpResponse);
			log.info(ThreadCreator.currentThread()+"Response sent to client");
			} 
		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			log.error(e);
		}

	}
}
	

public static void serviceRequest(String log4jfilename) throws IOException{
		System.out.println("Listening for connection on port 10008 ....");

		log4jfile = log4jfilename;
		socket = new ServerSocket(10008,numOfthreads);
				System.out.println("Thread-ID");
		for(int i =1;i<=numOfthreads;i++){		
		ThreadCreator tc = new ThreadCreator();
		tc.start();
		}	
	}
}


public class ThreadBuilder {
	public static void main( String args[]) throws IOException{
		 String log4jprop = args[0];
		ThreadCreator.serviceRequest(log4jprop);
	}
}